# Basic-Banking-System-TSF-

By- CHETASHRI PALYADWAR

I have completed this project under internship offered by The Sparks Foundation(TSF). In this project we can transfer money and can view the transaction history for the same by using HTML,CSS & Javascript.
